/*    */ package org.vaadin.applet.sample;
/*    */ 
/*    */ import com.vaadin.Application;
/*    */ import com.vaadin.ui.Label;
/*    */ import com.vaadin.ui.Window;
/*    */ 
/*    */ public class AppletIntegrationSampleApplication extends Application
/*    */ {
/*    */   private static final long serialVersionUID = -2720874981487688798L;
/*    */ 
/*    */   public void init()
/*    */   {
/* 13 */     Window mainWindow = new Window("AppletIntegration Sample Application");
/* 14 */     Label label = new Label("Hello Vaadin user");
/* 15 */     mainWindow.addComponent(label);
/* 16 */     setMainWindow(mainWindow);
/*    */   }
/*    */ }

/* Location:           /opt/workspace_vasja/DotMatrixPrinter/classes/
 * Qualified Name:     org.vaadin.applet.sample.AppletIntegrationSampleApplication
 * JD-Core Version:    0.6.0
 */