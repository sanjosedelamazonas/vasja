/*     */ package org.vaadin.applet;
/*     */ 
/*     */ import com.vaadin.Application;
/*     */ import com.vaadin.terminal.PaintException;
/*     */ import com.vaadin.terminal.PaintTarget;
/*     */ import com.vaadin.terminal.gwt.server.WebApplicationContext;
/*     */ import com.vaadin.ui.AbstractComponent;
/*     */ import com.vaadin.ui.ClientWidget;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.vaadin.applet.client.ui.VAppletIntegration;
/*     */ 
/*     */ @ClientWidget(VAppletIntegration.class)
/*     */ public class AppletIntegration extends AbstractComponent
/*     */ {
/*     */   private static final long serialVersionUID = 6061722679712017720L;
/*  24 */   private String appletClass = null;
/*     */   private String codebase;
/*     */   private String name;
/*  27 */   private List<String> appletArchives = null;
/*  28 */   private Map<String, String> appletParams = null;
/*     */ 
/*  30 */   private String command = null;
/*  31 */   private String[] commandParams = null;
/*     */ 
/*     */   public void paintContent(PaintTarget target) throws PaintException
/*     */   {
/*  35 */     super.paintContent(target);
/*     */ 
/*  38 */     if (this.appletClass == null)
/*     */     {
/*  40 */       return;
/*     */     }
/*  42 */     target.addAttribute("appletClass", this.appletClass);
/*     */ 
/*  45 */     String sid = getHttpSessionId();
/*  46 */     if (sid != null) {
/*  47 */       target.addAttribute("appletSession", sid);
/*     */     }
/*     */ 
/*  51 */     if (this.appletArchives != null) {
/*  52 */       target.addAttribute("appletArchives", 
/*  53 */         this.appletArchives.toArray(new String[this.appletArchives.size()]));
/*     */     }
/*     */ 
/*  57 */     if (this.codebase != null) {
/*  58 */       target.addAttribute("appletCodebase", 
/*  59 */         this.codebase);
/*     */     }
/*     */ 
/*  63 */     if (this.name != null) {
/*  64 */       target.addAttribute("appletName", this.name);
/*     */     }
/*     */ 
/*  68 */     if (this.appletParams != null) {
/*  69 */       target.addAttribute("appletParamNames", 
/*  70 */         this.appletParams);
/*     */     }
/*     */ 
/*  74 */     if (this.command != null) {
/*  75 */       target.addAttribute("cmd", this.command);
/*  76 */       this.command = null;
/*     */     }
/*     */ 
/*  79 */     if (this.commandParams != null) {
/*  80 */       target.addAttribute("cmdParams", 
/*  81 */         this.commandParams);
/*  82 */       this.commandParams = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected String getHttpSessionId()
/*     */   {
/*  95 */     Application app = getApplication();
/*  96 */     if (app != null) {
/*  97 */       WebApplicationContext ctx = (WebApplicationContext)app
/*  98 */         .getContext();
/*  99 */       if (ctx != null) {
/* 100 */         return ctx.getHttpSession().getId();
/*     */       }
/*     */     }
/* 103 */     return null;
/*     */   }
/*     */ 
/*     */   public void executeCommand(String command)
/*     */   {
/* 112 */     this.command = command;
/* 113 */     this.commandParams = null;
/* 114 */     requestRepaint();
/*     */   }
/*     */ 
/*     */   public void executeCommand(String command, String[] params)
/*     */   {
/* 124 */     this.command = command;
/* 125 */     this.commandParams = params;
/* 126 */     requestRepaint();
/*     */   }
/*     */ 
/*     */   protected void setAppletClass(String appletClass)
/*     */   {
/* 138 */     this.appletClass = appletClass;
/*     */   }
/*     */ 
/*     */   protected String getAppletClass()
/*     */   {
/* 150 */     return this.appletClass;
/*     */   }
/*     */ 
/*     */   protected void setAppletArchives(List<String> appletArchives)
/*     */   {
/* 162 */     this.appletArchives = appletArchives;
/*     */   }
/*     */ 
/*     */   protected List<String> getAppletArchives()
/*     */   {
/* 174 */     return this.appletArchives;
/*     */   }
/*     */ 
/*     */   protected String getAppletParams(String paramName)
/*     */   {
/* 186 */     if (this.appletParams == null) {
/* 187 */       return null;
/*     */     }
/* 189 */     return (String)this.appletParams.get(paramName);
/*     */   }
/*     */ 
/*     */   protected void setAppletParams(String paramName, String paramValue)
/*     */   {
/* 202 */     if (this.appletParams == null) {
/* 203 */       this.appletParams = new HashMap();
/*     */     }
/* 205 */     this.appletParams.put(paramName, paramValue);
/*     */   }
/*     */ 
/*     */   protected Map<String, String> getAppletParams()
/*     */   {
/* 217 */     return Collections.unmodifiableMap(this.appletParams);
/*     */   }
/*     */ 
/*     */   public void setCodebase(String codebase)
/*     */   {
/* 229 */     this.codebase = codebase;
/*     */   }
/*     */ 
/*     */   public String getCodebase()
/*     */   {
/* 242 */     return this.codebase;
/*     */   }
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/* 254 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/* 267 */     return this.name;
/*     */   }
/*     */ }

/* Location:           /opt/workspace_vasja/DotMatrixPrinter/classes/
 * Qualified Name:     org.vaadin.applet.AppletIntegration
 * JD-Core Version:    0.6.0
 */