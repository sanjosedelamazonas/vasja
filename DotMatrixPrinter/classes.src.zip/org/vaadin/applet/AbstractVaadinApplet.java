/*     */ package org.vaadin.applet;
/*     */ 
/*     */ import java.applet.Applet;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Locale;
/*     */ 
/*     */ public abstract class AbstractVaadinApplet extends Applet
/*     */ {
/*     */   private static final long serialVersionUID = -1091104541127400420L;
/*     */   protected static final String PARAM_APP_SESSION = "appSession";
/*     */   protected static final String PARAM_APP_URL = "appUrl";
/*     */   protected static final String PARAM_APPLET_ID = "appletId";
/*     */   protected static final String PARAM_PAINTABLE_ID = "paintableId";
/*     */   protected static final String PARAM_APP_DEBUG = "appDebug";
/*     */   protected static final String PARAM_ACTION_URL = "actionUrl";
/*  36 */   protected static long MAX_JS_WAIT_TIME = 10000L;
/*     */ 
/*  38 */   private boolean debug = false;
/*     */   private JsPollerThread pollerThread;
/*  42 */   private Object pollerLock = new Object[0];
/*     */ 
/*  44 */   public boolean runPoller = true;
/*     */   private String applicationURL;
/*     */   private String sessionCookie;
/*     */   private String paintableId;
/*     */   private String appletId;
/*     */   private String actionUrl;
/*     */ 
/*     */   public void init()
/*     */   {
/*  58 */     setDebug("true".equals(getParameter("appDebug")));
/*  59 */     setAppletId(getParameter("appletId"));
/*  60 */     setPaintableId(getParameter("paintableId"));
/*  61 */     setApplicationURL(getParameter("appUrl"));
/*  62 */     setApplicationSessionCookie(getParameter("appSession"));
/*  63 */     setAction(getParameter("actionUrl"));
/*     */ 
/*  66 */     this.pollerThread = new JsPollerThread();
/*  67 */     this.pollerThread.start();
/*     */   }
/*     */ 
/*     */   private void setAction(String submitAction) {
/*  71 */     this.actionUrl = submitAction;
/*  72 */     debug("actionUrl=" + submitAction);
/*     */   }
/*     */ 
/*     */   protected String getActionUrl()
/*     */   {
/*  86 */     return this.actionUrl;
/*     */   }
/*     */ 
/*     */   private void setAppletId(String appletId)
/*     */   {
/*  95 */     this.appletId = appletId;
/*  96 */     debug("appletId=" + appletId);
/*     */   }
/*     */ 
/*     */   protected String getAppleteId()
/*     */   {
/* 105 */     return this.appletId;
/*     */   }
/*     */ 
/*     */   private void setPaintableId(String paintableId)
/*     */   {
/* 115 */     this.paintableId = paintableId;
/* 116 */     debug("paintableId=" + paintableId);
/*     */   }
/*     */ 
/*     */   protected String getPaintableId()
/*     */   {
/* 125 */     return this.paintableId;
/*     */   }
/*     */ 
/*     */   private void setApplicationSessionCookie(String appSessionCookie)
/*     */   {
/* 134 */     this.sessionCookie = appSessionCookie;
/* 135 */     debug("sessionCookie=" + this.sessionCookie);
/*     */   }
/*     */ 
/*     */   protected String getApplicationSessionCookie()
/*     */   {
/* 145 */     return this.sessionCookie;
/*     */   }
/*     */ 
/*     */   private void setApplicationURL(String appUrl)
/*     */   {
/* 154 */     this.applicationURL = appUrl;
/* 155 */     debug("applicationURL=" + this.applicationURL);
/*     */   }
/*     */ 
/*     */   protected String getApplicationURL()
/*     */   {
/* 164 */     return this.applicationURL;
/*     */   }
/*     */ 
/*     */   protected void debug(String string)
/*     */   {
/* 173 */     if (!isDebug()) {
/* 174 */       return;
/*     */     }
/* 176 */     System.err.println("debug: " + string);
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 185 */     this.runPoller = false;
/* 186 */     super.destroy();
/*     */   }
/*     */ 
/*     */   public void vaadinSync()
/*     */   {
/* 196 */     jsCallAsync("vaadin.forceSync()");
/*     */   }
/*     */ 
/*     */   public void vaadinUpdateVariable(String variableName, boolean newValue, boolean immediate)
/*     */   {
/* 208 */     String cmd = "vaadin.appletUpdateBooleanVariable('" + getPaintableId() + 
/* 209 */       "','" + variableName + "'," + newValue + "," + immediate + 
/* 210 */       ")";
/* 211 */     jsCall(cmd);
/*     */   }
/*     */ 
/*     */   public void vaadinUpdateVariable(String variableName, int newValue, boolean immediate)
/*     */   {
/* 223 */     String cmd = "vaadin.appletUpdateIntVariable('" + getPaintableId() + 
/* 224 */       "','" + variableName + "'," + newValue + "," + immediate + 
/* 225 */       ")";
/* 226 */     jsCall(cmd);
/*     */   }
/*     */ 
/*     */   public void vaadinUpdateVariable(String variableName, double newValue, boolean immediate)
/*     */   {
/* 238 */     String cmd = "vaadin.appletUpdateDoubleVariable('" + getPaintableId() + 
/* 239 */       "','" + variableName + "'," + newValue + "," + immediate + 
/* 240 */       ")";
/* 241 */     jsCall(cmd);
/*     */   }
/*     */ 
/*     */   public void vaadinUpdateVariable(String variableName, String newValue, boolean immediate)
/*     */   {
/* 253 */     newValue = escapeJavaScript(newValue);
/* 254 */     String cmd = "vaadin.appletUpdateStringVariable('" + getPaintableId() + 
/* 255 */       "','" + variableName + "','" + newValue + "'," + immediate + 
/* 256 */       ")";
/* 257 */     jsCall(cmd);
/*     */   }
/*     */ 
/*     */   private Object jsCall(String cmd)
/*     */   {
/*     */     try
/*     */     {
/* 272 */       return jsCallSync(cmd); } catch (InterruptedException e) {
/*     */     }
/* 274 */     throw new RuntimeException(
/* 275 */       "Synchronous JavaScript call timed out.", e);
/*     */   }
/*     */ 
/*     */   public void jsCallAsync(String command)
/*     */   {
/* 287 */     JSCallThread t = new JSCallThread(command);
/* 288 */     t.start();
/*     */   }
/*     */ 
/*     */   public Object jsCallSync(String command)
/*     */     throws InterruptedException
/*     */   {
/* 298 */     JSCallThread t = new JSCallThread(command);
/* 299 */     t.start();
/* 300 */     t.join(MAX_JS_WAIT_TIME);
/* 301 */     return t.getResult();
/*     */   }
/*     */ 
/*     */   public void setDebug(boolean debug)
/*     */   {
/* 467 */     boolean change = this.debug ^ debug;
/* 468 */     this.debug = debug;
/* 469 */     if (change)
/* 470 */       debug(isDebug());
/*     */   }
/*     */ 
/*     */   public void debug(Exception e)
/*     */   {
/* 475 */     if (!isDebug()) {
/* 476 */       return;
/*     */     }
/* 478 */     System.err.println("debug: Exception " + e);
/* 479 */     e.printStackTrace();
/*     */   }
/*     */ 
/*     */   public boolean isDebug() {
/* 483 */     return this.debug;
/*     */   }
/*     */ 
/*     */   public void execute(String command)
/*     */   {
/* 494 */     execute(command, null);
/*     */   }
/*     */ 
/*     */   public void execute(String command, Object[] params)
/*     */   {
/* 505 */     if (this.pollerThread == null) {
/* 506 */       debug("Poller thread stopped. Cannot execute: '" + command + "'");
/* 507 */       return;
/*     */     }
/* 509 */     synchronized (this.pollerLock) {
/* 510 */       this.pollerThread.jsCommand = command;
/* 511 */       this.pollerThread.jsParams = params;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected abstract void doExecute(String paramString, Object[] paramArrayOfObject);
/*     */ 
/*     */   public static String escapeJavaScript(String str)
/*     */   {
/* 568 */     if (str == null) {
/* 569 */       return null;
/*     */     }
/*     */ 
/* 572 */     StringBuffer writer = new StringBuffer(str.length() * 2);
/*     */ 
/* 574 */     int sz = str.length();
/* 575 */     for (int i = 0; i < sz; i++) {
/* 576 */       char ch = str.charAt(i);
/*     */ 
/* 579 */       if (ch > '࿿') {
/* 580 */         writer.append("\\u");
/* 581 */         writer.append(hex(ch));
/* 582 */       } else if (ch > 'ÿ') {
/* 583 */         writer.append("\\u0");
/* 584 */         writer.append(hex(ch));
/* 585 */       } else if (ch > '') {
/* 586 */         writer.append("\\u00");
/* 587 */         writer.append(hex(ch));
/* 588 */       } else if (ch < ' ') {
/* 589 */         switch (ch) {
/*     */         case '\b':
/* 591 */           writer.append('\\');
/* 592 */           writer.append('b');
/* 593 */           break;
/*     */         case '\n':
/* 595 */           writer.append('\\');
/* 596 */           writer.append('n');
/* 597 */           break;
/*     */         case '\t':
/* 599 */           writer.append('\\');
/* 600 */           writer.append('t');
/* 601 */           break;
/*     */         case '\f':
/* 603 */           writer.append('\\');
/* 604 */           writer.append('f');
/* 605 */           break;
/*     */         case '\r':
/* 607 */           writer.append('\\');
/* 608 */           writer.append('r');
/* 609 */           break;
/*     */         case '\013':
/*     */         default:
/* 611 */           if (ch > '\017') {
/* 612 */             writer.append("\\u00");
/* 613 */             writer.append(hex(ch)); continue;
/*     */           }
/* 615 */           writer.append("\\u000");
/* 616 */           writer.append(hex(ch));
/*     */ 
/* 618 */           break;
/*     */         }
/*     */       } else {
/* 621 */         switch (ch)
/*     */         {
/*     */         case '\'':
/* 625 */           writer.append('\\');
/* 626 */           writer.append('\'');
/* 627 */           break;
/*     */         case '"':
/* 629 */           writer.append('\\');
/* 630 */           writer.append('"');
/* 631 */           break;
/*     */         case '\\':
/* 633 */           writer.append('\\');
/* 634 */           writer.append('\\');
/* 635 */           break;
/*     */         default:
/* 637 */           writer.append(ch);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 643 */     return writer.toString();
/*     */   }
/*     */ 
/*     */   private static String hex(char ch)
/*     */   {
/* 657 */     return Integer.toHexString(ch).toUpperCase(Locale.ENGLISH);
/*     */   }
/*     */ 
/*     */   public class JSCallThread extends Thread
/*     */   {
/* 361 */     private String command = null;
/* 362 */     private Object result = null;
/* 363 */     private boolean success = false;
/*     */ 
/*     */     public JSCallThread(String command)
/*     */     {
/* 374 */       this.command = command.replaceAll("\n", " ");
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 380 */       AbstractVaadinApplet.this.debug("Call JavaScript '" + this.command + "'");
/*     */ 
/* 382 */       String jscmd = this.command;
/*     */       try
/*     */       {
/* 385 */         Method getWindowMethod = null;
/* 386 */         Method evalMethod = null;
/* 387 */         Object jsWin = null;
/* 388 */         Class c = Class.forName("netscape.javascript.JSObject");
/* 389 */         Method[] ms = c.getMethods();
/* 390 */         for (int i = 0; i < ms.length; i++) {
/* 391 */           if (ms[i].getName().compareTo("getWindow") == 0)
/* 392 */             getWindowMethod = ms[i];
/* 393 */           else if (ms[i].getName().compareTo("eval") == 0) {
/* 394 */             evalMethod = ms[i];
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 400 */         jsWin = getWindowMethod.invoke(c, 
/* 401 */           new Object[] { AbstractVaadinApplet.this });
/*     */ 
/* 404 */         this.result = evalMethod.invoke(jsWin, new Object[] { jscmd });
/*     */ 
/* 406 */         if ((!(this.result instanceof String)) && (this.result != null)) {
/* 407 */           this.result = this.result.toString();
/*     */         }
/* 409 */         this.success = true;
/* 410 */         AbstractVaadinApplet.this.debug("JavaScript result: " + this.result);
/*     */       }
/*     */       catch (InvocationTargetException e)
/*     */       {
/* 414 */         this.success = true;
/* 415 */         this.result = e;
/* 416 */         AbstractVaadinApplet.this.debug(e);
/*     */       } catch (Exception e) {
/* 418 */         this.success = true;
/* 419 */         this.result = e;
/* 420 */         AbstractVaadinApplet.this.debug(e);
/*     */       }
/*     */     }
/*     */ 
/*     */     public Object getResult()
/*     */     {
/* 430 */       return this.result;
/*     */     }
/*     */ 
/*     */     public String getResultAsString()
/*     */     {
/* 439 */       if (this.result == null) {
/* 440 */         return null;
/*     */       }
/* 442 */       return (String)((this.result instanceof String) ? this.result : this.result
/* 443 */         .toString());
/*     */     }
/*     */ 
/*     */     public Exception getException()
/*     */     {
/* 452 */       return (Exception)((this.result instanceof Exception) ? this.result : null);
/*     */     }
/*     */ 
/*     */     public boolean isSuccess()
/*     */     {
/* 461 */       return this.success;
/*     */     }
/*     */   }
/*     */ 
/*     */   public class JsPollerThread extends Thread
/*     */   {
/*     */     private static final long POLLER_DELAY = 100L;
/*     */     private String jsCommand;
/*     */     private Object[] jsParams;
/*     */ 
/*     */     public JsPollerThread()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 322 */       AbstractVaadinApplet.this.debug("Poller thread started.");
/* 323 */       while (AbstractVaadinApplet.this.runPoller)
/*     */       {
/* 326 */         String cmd = null;
/* 327 */         Object[] params = (Object[])null;
/* 328 */         synchronized (AbstractVaadinApplet.this.pollerLock) {
/* 329 */           if (this.jsCommand != null) {
/* 330 */             cmd = this.jsCommand;
/* 331 */             params = this.jsParams;
/* 332 */             this.jsCommand = null;
/* 333 */             this.jsParams = null;
/* 334 */             AbstractVaadinApplet.this.debug("Received JavaScript command '" + cmd + "'");
/*     */           }
/*     */         }
/*     */ 
/* 338 */         if (cmd != null) {
/* 339 */           AbstractVaadinApplet.this.doExecute(cmd, params);
/*     */         }
/*     */         try
/*     */         {
/* 343 */           Thread.sleep(100L);
/*     */         } catch (InterruptedException localInterruptedException) {
/*     */         }
/*     */       }
/* 347 */       AbstractVaadinApplet.this.debug("Poller thread stopped.");
/*     */     }
/*     */   }
/*     */ }

/* Location:           /opt/workspace_vasja/DotMatrixPrinter/classes/
 * Qualified Name:     org.vaadin.applet.AbstractVaadinApplet
 * JD-Core Version:    0.6.0
 */