/*     */ package org.vaadin.applet.client.ui;
/*     */ 
/*     */ import com.google.gwt.core.client.GWT;
/*     */ import com.google.gwt.user.client.Cookies;
/*     */ import com.google.gwt.user.client.ui.HTML;
/*     */ import com.vaadin.terminal.gwt.client.ApplicationConfiguration;
/*     */ import com.vaadin.terminal.gwt.client.ApplicationConnection;
/*     */ import com.vaadin.terminal.gwt.client.Paintable;
/*     */ import com.vaadin.terminal.gwt.client.UIDL;
/*     */ import com.vaadin.terminal.gwt.client.VConsole;
/*     */ import com.vaadin.terminal.gwt.client.ValueMap;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class VAppletIntegration extends HTML
/*     */   implements Paintable
/*     */ {
/*     */   protected static final String PARAM_APP_SESSION = "appSession";
/*     */   protected static final String PARAM_APP_URL = "appUrl";
/*     */   protected static final String PARAM_APP_DEBUG = "appDebug";
/*     */   protected static final String PARAM_PAINTABLE_ID = "paintableId";
/*     */   protected static final String PARAM_APPLET_ID = "appletId";
/*     */   protected static final String PARAM_ACTION_URL = "actionUrl";
/*     */   public static final String ATTR_APPLET_SESSION = "appletSession";
/*     */   public static final String ATTR_APPLET_CLASS = "appletClass";
/*     */   public static final String ATTR_APPLET_ARCHIVES = "appletArchives";
/*     */   public static final String ATTR_APPLET_PARAM_NAMES = "appletParamNames";
/*     */   public static final String ATTR_APPLET_PARAM_VALUES = "appletParamValues";
/*     */   public static final String ATTR_APPLET_CODEBASE = "appletCodebase";
/*     */   public static final String ATTR_APPLET_NAME = "appletName";
/*     */   public static final String ATTR_APPLET_ACTION = "action";
/*     */   public static final String ATTR_CMD = "cmd";
/*     */   public static final String ATTR_CMD_PARAMS = "cmdParams";
/*     */   public static final String CLASSNAME = "v-applet";
/*     */   protected String paintableId;
/*     */   protected ApplicationConnection client;
/*     */   private String appletId;
/*     */   private String appletName;
/*     */   private boolean appletInitialized;
/*     */   private String appletClass;
/*  66 */   private String[] archives = new String[0];
/*     */   private Map<String, String> appletParameters;
/*     */   private String appletSession;
/*  69 */   private String height = "0";
/*  70 */   private String width = "0";
/*     */   private String codebase;
/*     */   private String action;
/*     */ 
/*     */   public VAppletIntegration()
/*     */   {
/*  81 */     setHTML("");
/*     */ 
/*  84 */     this.appletId = "v-applet";
/*  85 */     this.appletName = null;
/*     */ 
/*  89 */     setStyleName("v-applet");
/*     */   }
/*     */ 
/*     */   public void updateFromUIDL(UIDL uidl, ApplicationConnection client)
/*     */   {
/*  99 */     if (client.updateComponent(this, uidl, true))
/*     */     {
/* 102 */       return;
/*     */     }
/*     */ 
/* 107 */     this.client = client;
/*     */ 
/* 110 */     exportClientUpdateVariable(client);
/*     */ 
/* 113 */     this.paintableId = uidl.getId();
/*     */ 
/* 115 */     this.appletId = ("v-applet" + this.paintableId);
/* 116 */     if (this.appletName == null) {
/* 117 */       this.appletName = this.appletId;
/*     */     }
/*     */ 
/* 121 */     if (!this.appletInitialized)
/*     */     {
/* 124 */       if (!uidl.hasAttribute("appletClass")) {
/* 125 */         VConsole.log("Missing attribute appletClass");
/* 126 */         return;
/*     */       }
/* 128 */       this.appletClass = uidl.getStringAttribute("appletClass");
/*     */ 
/* 131 */       if (!uidl.hasAttribute("appletSession")) {
/* 132 */         VConsole.log("Missing attribute appletSession");
/* 133 */         return;
/*     */       }
/* 135 */       this.appletSession = uidl.getStringAttribute("appletSession");
/*     */ 
/* 138 */       if (uidl.hasAttribute("appletName")) {
/* 139 */         this.appletName = uidl.getStringAttribute("appletName");
/*     */       }
/* 141 */       if (this.appletName == null) {
/* 142 */         this.appletName = this.appletId;
/*     */       }
/*     */ 
/* 146 */       if (!uidl.hasAttribute("appletArchives")) {
/* 147 */         VConsole.log("Missing attribute appletArchives");
/* 148 */         return;
/*     */       }
/*     */ 
/* 152 */       if (uidl.hasAttribute("appletCodebase")) {
/* 153 */         this.codebase = uidl.getStringAttribute("appletCodebase");
/*     */       }
/*     */ 
/* 157 */       if (uidl.hasAttribute("width"))
/* 158 */         setWidth(uidl.getStringAttribute("width"));
/*     */       else {
/* 160 */         setWidth("0");
/*     */       }
/*     */ 
/* 163 */       if (uidl.hasAttribute("height"))
/* 164 */         setHeight(uidl.getStringAttribute("height"));
/*     */       else {
/* 166 */         setHeight("0");
/*     */       }
/*     */ 
/* 169 */       if (uidl.hasVariable("action")) {
/* 170 */         this.action = client.translateVaadinUri(uidl.getStringVariable("action"));
/*     */       }
/*     */ 
/* 173 */       this.archives = uidl.getStringArrayAttribute("appletArchives");
/*     */ 
/* 176 */       this.appletParameters = getDefaultIntegrationParameters();
/* 177 */       if (uidl.hasAttribute("appletParamNames")) {
/* 178 */         ValueMap map = uidl.getMapAttribute("appletParamNames");
/* 179 */         Set keys = map.getKeySet();
/* 180 */         for (String key : keys) {
/* 181 */           this.appletParameters.put(key, map.getString(key));
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 186 */       setHTML(getAppletHTML());
/* 187 */       this.appletInitialized = true;
/*     */     }
/*     */ 
/* 191 */     String cmd = null;
/* 192 */     String[] cmdParams = (String[])null;
/* 193 */     if (uidl.hasAttribute("cmd")) {
/* 194 */       cmd = uidl.getStringAttribute("cmd");
/*     */     }
/* 196 */     if (uidl.hasAttribute("cmdParams")) {
/* 197 */       cmdParams = uidl.getStringArrayAttribute("cmdParams");
/*     */     }
/* 199 */     if (cmd != null)
/* 200 */       execute(cmd, cmdParams);
/*     */   }
/*     */ 
/*     */   private static native void exportClientUpdateVariable(ApplicationConnection paramApplicationConnection);
/*     */ 
/*     */   public void execute(String cmd, String[] cmdParams)
/*     */   {
/* 229 */     VConsole.log("Applet command: " + getAppletId() + ",'" + cmd + "','" + 
/* 230 */       cmdParams + "'");
/* 231 */     if ((cmdParams != null) && (cmdParams.length > 0))
/* 232 */       internalAppletExecute(getAppletId(), cmd, cmdParams);
/*     */     else
/* 234 */       internalAppletExecute(getAppletId(), cmd);
/*     */   }
/*     */ 
/*     */   private native void internalAppletExecute(String paramString1, String paramString2);
/*     */ 
/*     */   private native void internalAppletExecute(String paramString1, String paramString2, String[] paramArrayOfString);
/*     */ 
/*     */   protected String getPaintableId()
/*     */   {
/* 275 */     return this.paintableId;
/*     */   }
/*     */ 
/*     */   protected String getAppletHTML()
/*     */   {
/* 289 */     List archives = getArchives();
/* 290 */     String archiveAttribute = "";
/* 291 */     if (archives != null) {
/* 292 */       boolean first = true;
/* 293 */       for (String a : archives) {
/* 294 */         if (!first)
/* 295 */           archiveAttribute = archiveAttribute + ",";
/*     */         else {
/* 297 */           first = false;
/*     */         }
/* 299 */         archiveAttribute = archiveAttribute + a;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 304 */     Map appletParams = getAppletParameters();
/* 305 */     String appletParamStr = "";
/* 306 */     if (appletParams != null) {
/* 307 */       for (String name : appletParams.keySet()) {
/* 308 */         appletParamStr = appletParamStr + "<param name=\"" + name + "\" value=\"" + 
/* 309 */           (String)appletParams.get(name) + "\" />";
/*     */       }
/*     */     }
/*     */ 
/* 313 */     return "<applet mayscript=\"true\" code=\"" + getAppletClass() + 
/* 314 */       "\" codebase=\"" + getCodebase() + "\" width=\"" + 
/* 315 */       getWidth() + "\" height=\"" + getHeight() + "\" id=\"" + 
/* 316 */       getAppletId() + "\" name=\"" + getAppletName() + 
/* 317 */       "\" archive=\"" + archiveAttribute + "\">" + appletParamStr + 
/* 318 */       "</applet>";
/*     */   }
/*     */ 
/*     */   private String getCodebase()
/*     */   {
/* 328 */     return this.codebase == null ? GWT.getModuleBaseURL() : this.codebase;
/*     */   }
/*     */ 
/*     */   protected String getHeight() {
/* 332 */     return this.height;
/*     */   }
/*     */ 
/*     */   protected String getWidth() {
/* 336 */     return this.width;
/*     */   }
/*     */ 
/*     */   public void setWidth(String w)
/*     */   {
/* 341 */     super.setWidth(w);
/* 342 */     this.width = w;
/*     */   }
/*     */ 
/*     */   public void setHeight(String h)
/*     */   {
/* 347 */     super.setHeight(h);
/* 348 */     this.height = h;
/*     */   }
/*     */ 
/*     */   protected Map<String, String> getAppletParameters()
/*     */   {
/* 357 */     return this.appletParameters;
/*     */   }
/*     */ 
/*     */   protected String getAppletId()
/*     */   {
/* 366 */     return this.appletId;
/*     */   }
/*     */ 
/*     */   protected String getAppletName()
/*     */   {
/* 375 */     return this.appletName;
/*     */   }
/*     */ 
/*     */   protected List<String> getArchives()
/*     */   {
/* 384 */     ArrayList res = new ArrayList();
/* 385 */     for (int i = 0; i < this.archives.length; i++) {
/* 386 */       res.add(this.archives[i]);
/*     */     }
/* 388 */     return res;
/*     */   }
/*     */ 
/*     */   protected String getAppletClass()
/*     */   {
/* 397 */     return this.appletClass;
/*     */   }
/*     */ 
/*     */   private Map<String, String> getDefaultIntegrationParameters()
/*     */   {
/* 406 */     Map res = new HashMap();
/*     */ 
/* 409 */     res.put("appletId", getAppletId());
/* 410 */     res.put("paintableId", getPaintableId());
/*     */ 
/* 412 */     String sessionId = this.appletSession;
/* 413 */     if (sessionId == null) {
/* 414 */       sessionId = Cookies.getCookie("JSESSIONID");
/*     */     }
/* 416 */     res.put("appSession", "JSESSIONID=" + sessionId);
/* 417 */     res.put("appDebug", 
/* 418 */       ApplicationConfiguration.isDebugMode() ? "true" : "false");
/* 419 */     res.put("appUrl", GWT.getHostPageBaseURL());
/* 420 */     res.put("actionUrl", GWT.getHostPageBaseURL() + this.action.substring(this.client.getAppUri().length()));
/* 421 */     return res;
/*     */   }
/*     */ }

/* Location:           /opt/workspace_vasja/DotMatrixPrinter/classes/
 * Qualified Name:     org.vaadin.applet.client.ui.VAppletIntegration
 * JD-Core Version:    0.6.0
 */