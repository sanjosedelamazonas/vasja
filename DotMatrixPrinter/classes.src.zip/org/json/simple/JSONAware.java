package org.json.simple;

public abstract interface JSONAware
{
  public abstract String toJSONString();
}

/* Location:           /opt/workspace_vasja/DotMatrixPrinter/classes/
 * Qualified Name:     org.json.simple.JSONAware
 * JD-Core Version:    0.6.0
 */